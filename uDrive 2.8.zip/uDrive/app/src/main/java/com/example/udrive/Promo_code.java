package com.example.udrive;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Promo_code extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_promo_code);
    }
}
